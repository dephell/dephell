# built-in
from sys import argv

# app
from .cli import main


main(argv[1:])
