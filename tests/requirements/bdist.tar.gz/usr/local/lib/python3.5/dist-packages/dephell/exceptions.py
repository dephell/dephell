

class MergeError(TypeError):
    """Cannot merge two dependencies
    """
    pass
