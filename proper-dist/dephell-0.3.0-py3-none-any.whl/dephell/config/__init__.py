# app
from .manager import Config


config = Config()


__all__ = ['Config', 'config']
