# app
from .cli import entrypoint


entrypoint()
